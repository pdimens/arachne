# Working Together

The bíogo project welcomes contributions from all. Contributors should foster an open and welcoming environment. When contributing or otherwise participating, please:

- Be friendly and welcoming
- Be patient
- Be thoughtful
- Be respectful
- Be charitable
- Avoid destructive behavior

Excerpted from the [Go conduct document](https://golang.org/conduct).
